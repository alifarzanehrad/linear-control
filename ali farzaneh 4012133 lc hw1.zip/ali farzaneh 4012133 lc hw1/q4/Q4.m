clear all;
s = tf('s');
g1 = 1/s;
g2 = 2*s + 1 ;
g3 = 1/(s^2 + 1);
g4 = s/(s+1);
h1 = 3/s;
h2 = (s-1)/(s+3);
h3 = s/(s^2 + 3*s + 1);
h4 = 1/(s+2);

[num,den]=linmod('untitled');
x=tf(num,den);
x = minreal(x)
poles = pole(x);
disp('The poles of the transfer function x are:');
disp(poles);